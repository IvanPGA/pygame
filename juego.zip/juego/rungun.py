import pygame
import sys
import random

pygame.init()

ANCHO_PANTALLA = 800
ALTO_PANTALLA = 400
pantalla = pygame.display.set_mode((ANCHO_PANTALLA, ALTO_PANTALLA))
pygame.display.set_caption("Run and Gun")

BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)

#con/jugador
posicion_jugador = [100, ALTO_PANTALLA - 70]
velocidad_jugador = 5
saltando = False
contador_salto = 9  
mirando_derecha = True 
vidas = 3

# jugador
jugador_imagen_derecha = pygame.image.load("soldado.png")
jugador_imagen_derecha = pygame.transform.scale(jugador_imagen_derecha, (50, 50))
jugador_imagen_izquierda = pygame.transform.flip(jugador_imagen_derecha, True, False)

#  bala
bala_imagen = pygame.image.load("bala.png")
bala_imagen = pygame.transform.scale(bala_imagen, (10, 5))

# zombies
zombie_imagenes = []
for i in range(1, 5):
    imagen_zombie = pygame.image.load(f"zombie{i}.png")
    imagen_zombie = pygame.transform.scale(imagen_zombie, (50, 50))
    zombie_imagenes.append(imagen_zombie)

#con/bala
balas = []
velocidad_bala = 8
puede_disparar = True

#con/zombies
zombies = []
velocidad_zombies = 4
intervalo_zombies = 1200  
pygame.time.set_timer(pygame.USEREVENT, intervalo_zombies)


fondo = pygame.image.load("background.png")
piso = pygame.image.load("floor.png")
fondo = pygame.transform.scale(fondo, (ANCHO_PANTALLA, ALTO_PANTALLA))
piso = pygame.transform.scale(piso, (ANCHO_PANTALLA, 20))


fondo_menu = pygame.image.load("fondomenu.jpeg")  # Carga de la imagen de fondo del menú
fondo_menu = pygame.transform.scale(fondo_menu, (ANCHO_PANTALLA, ALTO_PANTALLA))

fuente = pygame.font.SysFont(None, 55)

def mostrar_texto(texto, color, x, y):
    mensaje = fuente.render(texto, True, color)
    pantalla.blit(mensaje, (x, y))

def menu():
    while True:
        pantalla.blit(fondo_menu, (0, 0))  
        mostrar_texto("Presiona ENTER para jugar", BLANCO, ANCHO_PANTALLA // 4, ALTO_PANTALLA // 3)
        pygame.display.flip()

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RETURN:  
                    jugar()  

def jugar():
    global vidas, balas, zombies, posicion_jugador, saltando, contador_salto, mirando_derecha
    vidas = 3  
    balas = []  
    zombies = [] 
    posicion_jugador = [100, ALTO_PANTALLA - 70] 
    saltando = False
    contador_salto = 7

    tiempo_inicio = pygame.time.get_ticks()
    clock = pygame.time.Clock() 

    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.USEREVENT and pygame.time.get_ticks() - tiempo_inicio > 4000:
                zombie_x = random.choice([-50, ANCHO_PANTALLA + 50])
                zombie_y = ALTO_PANTALLA - 70
                zombie_imagen = random.choice(zombie_imagenes)
                zombies.append([zombie_x, zombie_y, zombie_imagen, 0])
        teclas = pygame.key.get_pressed()
        #movimiento
        if teclas[pygame.K_LEFT]:
            posicion_jugador[0] -= velocidad_jugador
            mirando_derecha = False
        if teclas[pygame.K_RIGHT]:
            posicion_jugador[0] += velocidad_jugador
            mirando_derecha = True

        #jugador dentro de bordes
        posicion_jugador[0] = max(0, min(posicion_jugador[0], ANCHO_PANTALLA - 50))

        #salto
        if not saltando:
            if teclas[pygame.K_SPACE]:
                saltando = True
        else:
            if contador_salto >= -7:
                neg = 1 if contador_salto >= 0 else -1
                posicion_jugador[1] -= (contador_salto ** 2) * 0.5 * neg
                contador_salto -= 1
            else:
                saltando = False
                contador_salto = 7

        # Disparo
        if teclas[pygame.K_d] and puede_disparar:
            x_bala = posicion_jugador[0] + (50 if mirando_derecha else -10)
            y_bala = posicion_jugador[1] + 20
            balas.append([x_bala, y_bala, mirando_derecha])
            puede_disparar = False
        if not teclas[pygame.K_d]:
            puede_disparar = True
        for bala in balas:
            bala[0] += velocidad_bala if bala[2] else -velocidad_bala

        #zombies movimiento y colisiones
        for zombie in zombies[:]:
            if zombie[0] < posicion_jugador[0]:
                zombie[0] += velocidad_zombies
                pantalla.blit(zombie[2], (zombie[0], zombie[1]))  
            else:
                zombie[0] -= velocidad_zombies
                zombie_invertido = pygame.transform.flip(zombie[2], True, False)
                pantalla.blit(zombie_invertido, (zombie[0], zombie[1]))  

            # zombie/jugador
            if (posicion_jugador[0] <= zombie[0] <= posicion_jugador[0] + 50) and (posicion_jugador[1] <= zombie[1] <= posicion_jugador[1] + 50):
                vidas -= 1
                zombies.remove(zombie)
                if vidas <= 0:
                    pantalla.fill(NEGRO)
                    mostrar_texto("GAME OVER", BLANCO, ANCHO_PANTALLA // 3, ALTO_PANTALLA // 3)
                    pygame.display.flip()
                    pygame.time.delay(3000)
                    return 

            # bala/zombie
            for bala in balas:
                if (bala[0] >= zombie[0] and bala[0] <= zombie[0] + 50) and (bala[1] >= zombie[1] and bala[1] <= zombie[1] + 50):
                    zombie[3] += 1  
                    balas.remove(bala)
                    if zombie[3] >= 3: 
                        zombies.remove(zombie)
                    break

        
        pantalla.blit(fondo, (0, 0))
        pantalla.blit(piso, (0, ALTO_PANTALLA - 20))

        # dirección jugador
        if mirando_derecha:
            pantalla.blit(jugador_imagen_derecha, (posicion_jugador[0], posicion_jugador[1]))
        else:
            pantalla.blit(jugador_imagen_izquierda, (posicion_jugador[0], posicion_jugador[1]))
        for bala in balas:
            if bala[2]:
                pantalla.blit(bala_imagen, (bala[0], bala[1]))
            else:
                bala_invertida = pygame.transform.flip(bala_imagen, True, False)
                pantalla.blit(bala_invertida, (bala[0], bala[1]))
        for zombie in zombies:
            if zombie[0] > posicion_jugador[0]:
                pantalla.blit(zombie_imagen, (zombie[0], zombie[1]))
            else:
                zombie_invertido = pygame.transform.flip(zombie[2], True, False)
                pantalla.blit(zombie_invertido, (zombie[0], zombie[1]))

        mostrar_texto(f'Vidas: {vidas}', BLANCO, 10, 10)
        pygame.display.flip()

        #60 FPS
        clock.tick(60)


menu()
